VÉNDELO - Proyecto Android para compilar APK

La app abre la tienda web:
https://vendelo.tiendavendeloo.workers.dev/

ESTE ZIP NO CONTIENE UN APK YA COMPILADO.
Incluye el proyecto fuente y un flujo de GitHub Actions para que GitHub compile el APK en la nube.

COMPILAR DESDE GITHUB (sin instalar Android Studio en el celular):
1. En una computadora, inicia sesión en https://github.com/ y crea un repositorio nuevo llamado VendeloAndroid.
2. Descomprime este ZIP y sube TODO el contenido de la carpeta al repositorio (incluida la carpeta oculta .github).
3. En GitHub, abre la pestaña Actions y habilita los workflows si GitHub lo solicita.
4. Ejecuta "Build VÉNDELO APK" con el botón Run workflow, o espera a que termine el primer push.
5. Cuando termine correctamente, abre la ejecución y descarga el artefacto "Vendelo-debug-APK".
6. Dentro del ZIP descargado estará app-debug.apk. Descárgalo al Android e instálalo permitiendo instalaciones desde esa fuente.

COMPILAR CON ANDROID STUDIO:
- Abre esta carpeta como proyecto.
- Usa JDK 17 y Gradle 8.7.
- Ejecuta: gradle assembleDebug
- APK: app/build/outputs/apk/debug/app-debug.apk

Detalles:
- applicationId: com.vendelo.tienda
- Nombre visible: VÉNDELO
- Versión: 1.0
- La aplicación usa WebView y carga la tienda en línea.
- El APK debug sirve para pruebas. Para Google Play o distribución formal se debe generar una versión firmada de release.

Antes de distribuir:
- Probar registro, login, carrito, favoritos, pedidos y enlaces externos en teléfonos reales.
- Confirmar que todos los flujos de la tienda web funcionen dentro de WebView.
- Incorporar el logo oficial como icono de aplicación.
- Crear una clave de firma privada para producción y guardarla de forma segura.
